import java.lang.*;
import arjuna.JavaSim.*;

public class Main
{

public static void main (String[] args)
    {
	MachineShop m = new MachineShop();
	
	m.Await();

	System.exit(0);
    }
    
}

/*
 * This is a cludge to get visual C++ to compile .cc files
 * as C++ within a project.
 * Eventually this will be replaced with using C++SIM from
 * the shell, but will require users to install imake.
 */

 #include "ProcessList.cc"
 #include "ProcessIterator.cc"
 #include "ProcessCons.cc"
 #include "Process.cc"
 #include "nt_thread.cc"
 #include "Random.cc"
 #include "thread.cc"

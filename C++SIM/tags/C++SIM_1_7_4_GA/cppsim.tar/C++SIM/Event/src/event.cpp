/*
 * This is a cludge to get visual C++ to compile .cc files
 * as C++ within a project.
 * Eventually this will be replaced with using C++SIM from
 * the shell, but will require users to install imake.
 */

 #include "EntityList.cc"
 #include "Entity.cc"
 #include "Semaphore.cc"
 #include "TriggerQueue.cc"
 #include "ListElement.cc"
